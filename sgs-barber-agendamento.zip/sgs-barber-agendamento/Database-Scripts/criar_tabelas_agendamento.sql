-- Tabelas novas: horarios_barbeiro e agendamentos
-- (O Hibernate cria isso sozinho por causa do ddl-auto=update, mas é
--  importante ter o script versionado no Git para consulta/histórico)

CREATE TABLE horarios_barbeiro (
    id BIGSERIAL PRIMARY KEY,
    barbeiro_id BIGINT NOT NULL REFERENCES barbeiros(id),
    dia_semana INTEGER NOT NULL CHECK (dia_semana BETWEEN 1 AND 7), -- 1=segunda ... 7=domingo
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    CHECK (hora_inicio < hora_fim)
);

CREATE TABLE agendamentos (
    id BIGSERIAL PRIMARY KEY,
    cliente_id BIGINT NOT NULL REFERENCES clientes(id),
    barbeiro_id BIGINT NOT NULL REFERENCES barbeiros(id),
    servico_id BIGINT NOT NULL REFERENCES servicos(id),
    data_agendamento DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'AGENDADO',
    observacao VARCHAR(255),
    data_criacao TIMESTAMP NOT NULL DEFAULT now(),
    CHECK (hora_inicio < hora_fim)
);

CREATE INDEX idx_agendamentos_barbeiro_data ON agendamentos(barbeiro_id, data_agendamento);
