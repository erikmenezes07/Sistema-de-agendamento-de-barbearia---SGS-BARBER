package sgs_barber.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import sgs_barber.model.StatusAgendamento;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
public class AgendamentoDTO {
    private Long id;

    @NotNull(message = "O cliente é obrigatório")
    private Long clienteId;

    @NotNull(message = "O barbeiro é obrigatório")
    private Long barbeiroId;

    @NotNull(message = "O serviço é obrigatório")
    private Long servicoId;

    @NotNull(message = "A data do agendamento é obrigatória")
    private LocalDate dataAgendamento;

    @NotNull(message = "A hora de início é obrigatória")
    private LocalTime horaInicio;

    // Calculado automaticamente a partir da duração do serviço; não precisa vir no request
    private LocalTime horaFim;

    private StatusAgendamento status;

    private String observacao;

    private LocalDateTime dataCriacao;
}
