package sgs_barber.service;

import org.springframework.stereotype.Service;
import sgs_barber.dto.AgendamentoDTO;
import sgs_barber.dto.DisponibilidadeResponseDTO;
import sgs_barber.model.*;
import sgs_barber.repository.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AgendamentoService {

    private final AgendamentoRepository repository;
    private final ClienteRepository clienteRepository;
    private final BarbeiroRepository barbeiroRepository;
    private final ServicoRepository servicoRepository;
    private final HorarioBarbeiroRepository horarioBarbeiroRepository;

    // Granularidade usada para sugerir horários alternativos (em minutos)
    private static final int INTERVALO_SUGESTAO_MINUTOS = 15;

    public AgendamentoService(AgendamentoRepository repository,
                               ClienteRepository clienteRepository,
                               BarbeiroRepository barbeiroRepository,
                               ServicoRepository servicoRepository,
                               HorarioBarbeiroRepository horarioBarbeiroRepository) {
        this.repository = repository;
        this.clienteRepository = clienteRepository;
        this.barbeiroRepository = barbeiroRepository;
        this.servicoRepository = servicoRepository;
        this.horarioBarbeiroRepository = horarioBarbeiroRepository;
    }

    public List<AgendamentoDTO> listarPorCliente(Long clienteId) {
        return repository.findByClienteId(clienteId).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<AgendamentoDTO> listarPorBarbeiroEData(Long barbeiroId, LocalDate data) {
        return repository.findByBarbeiroIdAndDataAgendamento(barbeiroId, data)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    /**
     * Endpoint que a IA (ou qualquer front) chama antes de marcar: pergunta
     * "esse barbeiro está livre nesse dia/hora para esse serviço?"
     */
    public DisponibilidadeResponseDTO verificarDisponibilidade(Long barbeiroId, LocalDate data,
                                                                LocalTime horaInicio, Integer duracaoMinutos) {
        LocalTime horaFim = horaInicio.plusMinutes(duracaoMinutos);
        int diaSemana = data.getDayOfWeek().getValue(); // 1 = segunda ... 7 = domingo

        List<HorarioBarbeiro> turnos = horarioBarbeiroRepository.findByBarbeiroIdAndDiaSemana(barbeiroId, diaSemana);
        if (turnos.isEmpty()) {
            return new DisponibilidadeResponseDTO(false, "O barbeiro não atende neste dia da semana", List.of());
        }

        boolean dentroDoExpediente = turnos.stream()
                .anyMatch(t -> !horaInicio.isBefore(t.getHoraInicio()) && !horaFim.isAfter(t.getHoraFim()));
        if (!dentroDoExpediente) {
            return new DisponibilidadeResponseDTO(false, "Fora do horário de expediente do barbeiro",
                    listarHorariosLivres(barbeiroId, data, duracaoMinutos));
        }

        boolean conflito = haConflito(barbeiroId, data, horaInicio, horaFim, null);
        if (conflito) {
            return new DisponibilidadeResponseDTO(false, "Já existe um agendamento nesse horário",
                    listarHorariosLivres(barbeiroId, data, duracaoMinutos));
        }

        return new DisponibilidadeResponseDTO(true, null, List.of());
    }

    public AgendamentoDTO salvar(AgendamentoDTO dto) {
        Cliente cliente = clienteRepository.findById(dto.getClienteId())
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado com ID: " + dto.getClienteId()));
        Barbeiro barbeiro = barbeiroRepository.findById(dto.getBarbeiroId())
                .orElseThrow(() -> new RuntimeException("Barbeiro não encontrado com ID: " + dto.getBarbeiroId()));
        Servico servico = servicoRepository.findById(dto.getServicoId())
                .orElseThrow(() -> new RuntimeException("Serviço não encontrado com ID: " + dto.getServicoId()));

        LocalTime horaFim = dto.getHoraInicio().plusMinutes(servico.getDuracaoMinutos());

        DisponibilidadeResponseDTO disponibilidade = verificarDisponibilidade(
                dto.getBarbeiroId(), dto.getDataAgendamento(), dto.getHoraInicio(), servico.getDuracaoMinutos());
        if (!disponibilidade.isDisponivel()) {
            throw new RuntimeException("Horário indisponível: " + disponibilidade.getMotivo());
        }

        Agendamento agendamento = new Agendamento();
        agendamento.setCliente(cliente);
        agendamento.setBarbeiro(barbeiro);
        agendamento.setServico(servico);
        agendamento.setDataAgendamento(dto.getDataAgendamento());
        agendamento.setHoraInicio(dto.getHoraInicio());
        agendamento.setHoraFim(horaFim);
        agendamento.setStatus(StatusAgendamento.AGENDADO);
        agendamento.setObservacao(dto.getObservacao());

        return toDTO(repository.save(agendamento));
    }

    public AgendamentoDTO cancelar(Long id) {
        Agendamento agendamento = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Agendamento não encontrado com ID: " + id));
        agendamento.setStatus(StatusAgendamento.CANCELADO);
        return toDTO(repository.save(agendamento));
    }

    private boolean haConflito(Long barbeiroId, LocalDate data, LocalTime inicio, LocalTime fim, Long ignorarId) {
        List<Agendamento> doDia = repository.findByBarbeiroIdAndDataAgendamentoAndStatusNot(
                barbeiroId, data, StatusAgendamento.CANCELADO);

        return doDia.stream()
                .filter(a -> ignorarId == null || !a.getId().equals(ignorarId))
                // dois intervalos se sobrepõem quando um começa antes do outro terminar, nos dois sentidos
                .anyMatch(a -> inicio.isBefore(a.getHoraFim()) && a.getHoraInicio().isBefore(fim));
    }

    private List<LocalTime> listarHorariosLivres(Long barbeiroId, LocalDate data, Integer duracaoMinutos) {
        int diaSemana = data.getDayOfWeek().getValue();
        List<HorarioBarbeiro> turnos = horarioBarbeiroRepository.findByBarbeiroIdAndDiaSemana(barbeiroId, diaSemana);

        List<LocalTime> livres = new ArrayList<>();
        for (HorarioBarbeiro turno : turnos) {
            LocalTime cursor = turno.getHoraInicio();
            while (!cursor.plusMinutes(duracaoMinutos).isAfter(turno.getHoraFim())) {
                LocalTime fimSlot = cursor.plusMinutes(duracaoMinutos);
                if (!haConflito(barbeiroId, data, cursor, fimSlot, null)) {
                    livres.add(cursor);
                }
                cursor = cursor.plusMinutes(INTERVALO_SUGESTAO_MINUTOS);
            }
        }
        return livres;
    }

    private AgendamentoDTO toDTO(Agendamento a) {
        AgendamentoDTO dto = new AgendamentoDTO();
        dto.setId(a.getId());
        dto.setClienteId(a.getCliente().getId());
        dto.setBarbeiroId(a.getBarbeiro().getId());
        dto.setServicoId(a.getServico().getId());
        dto.setDataAgendamento(a.getDataAgendamento());
        dto.setHoraInicio(a.getHoraInicio());
        dto.setHoraFim(a.getHoraFim());
        dto.setStatus(a.getStatus());
        dto.setObservacao(a.getObservacao());
        dto.setDataCriacao(a.getDataCriacao());
        return dto;
    }
}
